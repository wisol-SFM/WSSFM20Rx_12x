ubuntu 14.04 install

sudo dpkg -i snek.deb
sudo apt-get -f install

sudo apt-get install python3-taglib

ubuntu 16.04 install
sudo apt-get install glib-networking*

ATS410=1 -> SIGFOX Ready modules and dev kits compatibility